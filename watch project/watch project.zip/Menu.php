<div id="menu-wrapper">
	<div id="menu">
		<ul>
			<li class="current_page_item">
			<li><a href="Template1.php"><u><b>Home Page</b></u></a></li>
			<li><a href="Wallcollection.php"><u><b>Wall collection</b></u></a></li>
			<li><a href="Mencollection.php"><u><b>Men's collection</b></u></a></li>
			<li><a href="Womencollection.php"><u><b>Women's collection</b></u></a></li>
		</ul>
	</div>
	<!-- end #menu --> 
</div>
