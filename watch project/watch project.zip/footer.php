<div id="footer">
	<p>2021. All rights reserved. Managed by: Vidhi Triedi</p>
</div>
<!-- end #footer -->