<div id="sidebar">
			<ul>
				<br>
				<li>
					<h3>Services provided by us</h3>
					<ul>
						<li>Movement Overhaul</li>
						<li>Battery change</li>
						<li>machine change</li>
						<li>Performance Tests</li>
						<li>Replacement of parts</li>
						<li>Strap change</li>
						</ul>
				</li>
				</ul>
		</div>
<div id="sidebar">
			<ul>
				<br>
				<li>
					<h3>Contact us</h3>
					<ul>
					<h4>Mobile :</h4> 9825685742<br>
					<h4>e-mail :</h4> trivedir2530@gmail.com<br>
					<h4>Address:</h4> "Shree Gurukrupa Watch co."
								  near parul petroleum,
								  Refinary road,
								  bajwa , vadodara-391310.
						
						</ul>
				</li>
				</ul>
		</div>