<div <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Shree Gurukrupa watch co.</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<?php
include './menu.php';
include './logo.php';
?>

<div id="wrapper"> 
	<!-- end #header -->
	<div id="page-bgtop"></div>
	<div id="page">
		<div><img src="images/Womendisplay1.jpg" width="920" height="300" alt="" /></div>		
<div id="content">
			<div class="post">
				<h2 class="title"><a href="#"><H5>Wall collection</H5></a></h2>
			<div style="clear: both;">&nbsp;</div>
				<div class="entry">
				<br>
<img src="images/Wall1.jpg" width="200" height="200" alt="" />
<img src="images/Wall2.jpg" width="200" height="200" alt="" />
<img src="images/Wall3.jpg" width="200" height="200" alt="" />
<img src="images/Wall4.jpg" width="200" height="200" alt="" />
<img src="images/Wall5.jpg" width="200" height="200" alt="" />
<img src="images/Wall6.jpg" width="200" height="200" alt="" />
<img src="images/Wall7.jpg" width="200" height="200" alt="" />			
<img src="images/Wall8.jpg" width="200" height="200" alt="" />	
<img src="images/Wall9.jpg" width="200" height="200" alt="" />	
</div>
			</div>
			
			
			<div style="clear: both;">&nbsp;</div>
		</div>
		
		
		
		<!-- end #content -->
		
<div id="sidebar">
			<ul>
				<br>
				<li>
					<h3>Products</h3>
					<ul>
						<li>Sonata</li>
						<li>Fastrack</li>
						<li>Titan</li>
						<li>Timex</li>
						<li>Casio</li>
						<li>And many more....</li>
						</ul>
				</li>
				</ul>
		</div>	
	<div style="clear: both;">&nbsp;</div>
	</div>
	<div id="page-bgbtm"></div>
	<!-- end #page --> 
</div>
<?php
include './footer.php';
?>
</body>
</html>
