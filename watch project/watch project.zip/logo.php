<div id="header-wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Shree Gurukrupa Watch Co.</a></h1>
			<p>Watch dealer and repairer</a></p>
		</div>